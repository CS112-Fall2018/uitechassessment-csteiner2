# Installation
> `npm install --save @types/tapable`

# Summary
This package contains type definitions for tapable (https://github.com/webpack/tapable.git).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tapable

Additional Details
 * Last updated: Sat, 14 Apr 2018 23:11:10 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by e-cloud <https://github.com/e-cloud>.
