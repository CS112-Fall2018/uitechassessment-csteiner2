# Installation
> `npm install --save @types/vfile-message`

# Summary
This package contains type definitions for vfile-message (https://github.com/vfile/vfile-message#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vfile-message

Additional Details
 * Last updated: Wed, 05 Dec 2018 19:00:19 GMT
 * Dependencies: @types/unist, @types/node
 * Global values: none

# Credits
These definitions were written by Junyoung Choi <https://github.com/rokt33r>.
