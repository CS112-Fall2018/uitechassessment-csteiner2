# Installation
> `npm install --save @types/vfile`

# Summary
This package contains type definitions for VFile (https://github.com/vfile/vfile).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vfile

Additional Details
 * Last updated: Wed, 05 Dec 2018 19:00:18 GMT
 * Dependencies: @types/unist, @types/vfile-message, @types/node
 * Global values: none

# Credits
These definitions were written by bizen241 <https://github.com/bizen241>, Junyoung Choi <https://github.com/rokt33r>.
